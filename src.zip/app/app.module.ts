import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptModule } from "nativescript-angular/nativescript.module";
import { NativeScriptUISideDrawerModule } from "nativescript-ui-sidedrawer/angular";
import { InternetConnectionService } from "./shared/services/internet-connection.service";
import { KinveyModule } from "kinvey-nativescript-sdk/lib/angular";
import {LoginComponent} from "./login/login.component";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";

import { UserService } from "./shared/user.service";
import { BookingService } from "./shared/booking/booking.service";
import { TasksService  } from "./shared/task.service";


@NgModule({
    bootstrap: [
        AppComponent
    ],
    imports: [
        AppRoutingModule,
        NativeScriptModule,
        NativeScriptUISideDrawerModule,
        KinveyModule.init({
            appKey: "kid_BkaDVxbSI",
            appSecret: "0d109f47dbf54a4bb5a9412bf08b537f"
        })
    ],
    declarations: [
        AppComponent,
        LoginComponent
    ],
    providers:[
        InternetConnectionService,
        UserService,
        BookingService,
        InternetConnectionService,
        TasksService
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class AppModule { }
