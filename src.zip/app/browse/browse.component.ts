/*import { Component, OnInit,AfterViewInit,EventEmitter, Input,Output, ViewContainerRef, ViewChild } from "@angular/core";
import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import * as app from "tns-core-modules/application";
import { Page } from "tns-core-modules/ui/page";
import { topmost } from "tns-core-modules/ui/frame";
import { Label } from "tns-core-modules/ui/label";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { GridLayout } from "tns-core-modules/ui/layouts/grid-layout";
import { Visibility } from "tns-core-modules/ui/enums";
import { isAndroid } from "tns-core-modules/platform";
import { Color } from "tns-core-modules/color";
import { ModalDialogOptions, ModalDialogService } from "nativescript-angular";
import { RouterExtensions } from "nativescript-angular/router";
import { RadDataFormComponent } from "nativescript-ui-dataform/angular/dataform-directives";

export class Booking {

    pickup:String;
    destination:String;
    date:Date; 
    time:Date; 
    seats:number;
    age:number;
    luggage:number;
    cellno:Number;
    confirm:boolean
}

@Component({
    selector: "Browse",
    templateUrl: "./browse.component.html"
})
export class BrowseComponent implements OnInit, AfterViewInit {
    booking:Booking;

    private _fromProviders: Array<String> = new Array<String>();

    album: { pickup: string, destination: string, date: Date,confirm: boolean, time: Date, seats:number,age:number,luggage: number,cellno:Number} = {
        pickup: " tyen",
        destination: " uniondale",
        date:null,
        time: null,
        seats:1,
        age:18,
        luggage:1,
        cellno:null,
        confirm: false,

        
    };

    constructor() {
        // Use the component constructor to inject providers.
    }

    ngOnInit(): void {
        // Init your component properties here.
    }

    ngAfterViewInit(): void {

    }

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.showDrawer();
    }
}
*/
import * as app from "tns-core-modules/application";
import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import { Component,AfterViewInit,EventEmitter, Input, OnInit, Output, ViewContainerRef, ViewChild} from "@angular/core";
import { Page } from "tns-core-modules/ui/page";
import { topmost } from "tns-core-modules/ui/frame";
import { Label } from "tns-core-modules/ui/label";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { GridLayout } from "tns-core-modules/ui/layouts/grid-layout";
import { Visibility } from "tns-core-modules/ui/enums";
import { isAndroid } from "tns-core-modules/platform";
import { Color } from "tns-core-modules/color";
import { GooglePlacesAutocomplete } from 'nativescript-google-places-autocomplete';
//import {getFile, getImage,getJSON,getString,request,HttpResponse} from "tns-core-modules/http";

//import {Person} from "./dataservice/person";
import { ModalDialogOptions, ModalDialogService } from "nativescript-angular";
//import { SearchAirportComponent } from "../search-airport/search-airport.component";

import { action } from "tns-core-modules/ui/dialogs";
import { getFile, getImage, getJSON, getString, request, HttpResponse } from "tns-core-modules/http";
import { NativeScriptDateTimePickerModule } from "nativescript-datetimepicker/angular";
import { TimePicker } from "tns-core-modules/ui/time-picker";
import { RouterExtensions } from "nativescript-angular/router";
import { ObservableArray } from "tns-core-modules/data/observable-array";


//import {Booking} from "../shared/booking/booking.model";
import {BookingService} from "../shared/booking/booking.service"
import {UserService} from "../shared/user.service"
import { RadDataForm } from "nativescript-ui-dataform";
import { RadDataFormComponent } from "nativescript-ui-dataform/angular/dataform-directives";

declare var UIImage: any;
declare var UIBarMetrics: any;
const DEFAULT_STEP = 'item-stepper';
const CURRENT_STEP = 'item-stepper current-step';
const SUCCESSFUL_STEP = 'item-stepper successful-step';
const BASE_COLOR = '#024184';

enum MoveTo {
    Left,
    Right
}

class DataItem {
	constructor(public name: string) {
	}
}
export class Booking {

    pickup:String;
    destination:String;
    date:Date; 
    time:Date; 
    seats:number;
    age:number;
    luggage:number;
    cellno:Number;
    confirm:boolean

}


@Component({
    selector: "browse",
    moduleId: module.id,
    templateUrl: "./browse.component.html",
    styleUrls: ['./browse.css']
})
export class BrowseComponent implements OnInit, AfterViewInit {
    
    booking:Booking;

    private _fromProviders: Array<String> = new Array<String>();
    
    album: { pickup: string, destination: string, date: Date,confirm: boolean, time: Date, seats:number,age:number,luggage: number,cellno:Number} = {
        pickup: " tyen",
        destination: " uniondale",
        date:null,
        time: null,
        seats:1,
        age:18,
        luggage:1,
        cellno:null,
        confirm: false,
        
    };

    
    
    public selectedDate: Date;
    public isOnOpenDepartureDate: boolean = false;
    public departureDate = new Date();
    public returnDate = new Date();
    public dateSelector = new Date();
    public currentStep = 1;
    public rotateItemImageStepper1 = 0;
    public rotateItemImageStepper2 = 0;
    public rotateItemImageStepper3 = 0;
    private _translate = 104;
    private _animationDuration = 300;
    private _btnPrevious: Button;
    private _btnNext: Button;
    private _itemStepper1: Label;
    private _itemStepper2: Label;
    private _itemStepper3: Label;
    private _itemImageStepper1: View;
    private _itemImageStepper2: View;
    private _itemImageStepper3: View;
    private moveTo: MoveTo = MoveTo.Right;
    private previousMovesTo: MoveTo;
    private _selectDateGridLayout: GridLayout;
    private _overlayGridLayout: GridLayout;
    @Output() openSelectDate = new EventEmitter();
    
    constructor(private page: Page,
        private _modalService: ModalDialogService,
		private routerExtensions: RouterExtensions,
		private bookingService: BookingService,
		private userService: UserService,
		private _vcRef: ViewContainerRef) {
		this._overlayGridLayout = this.page.getViewById('overlayGridLayout');
        var returnDate = new Date();
       // this.booking = new Booking();
        

        returnDate.setDate(returnDate.getDate() + 2);
        this.returnDate = returnDate;

this._fromProviders.push(" willowvale");
this._fromProviders.push(" uniondale");
this._fromProviders.push(" ugie");
this._fromProviders.push(" tylden");
this._fromProviders.push(" tyen");
this._fromProviders.push(" tsomo");
this._fromProviders.push(" tsolo");
this._fromProviders.push(" tsitsikamma");
this._fromProviders.push(" tshatshu");
this._fromProviders.push(" thomas-river");
this._fromProviders.push(" tarkastad");
this._fromProviders.push(" tabankulu");
this._fromProviders.push(" stormberg");
this._fromProviders.push(" steytlervill");
this._fromProviders.push(" steynsburg");
this._fromProviders.push(" sterkstroom");
this._fromProviders.push(" sithangameni");
this._fromProviders.push(" sidwadweni");
this._fromProviders.push(" sheshegu");
this._fromProviders.push(" seymour");
this._fromProviders.push(" rossouw");
this._fromProviders.push(" rietbron");
this._fromProviders.push(" redoubt");
this._fromProviders.push(" qumbu");
this._fromProviders.push(" qolora");
this._fromProviders.push(" qitsi");
this._fromProviders.push(" qamata");
this._fromProviders.push(" peddie");
this._fromProviders.push(" pearston");
this._fromProviders.push(" paterson");
this._fromProviders.push(" patensie");
this._fromProviders.push(" onder-smoordrif");
this._fromProviders.push(" oesterbaai");
this._fromProviders.push(" ntsimbini");
this._fromProviders.push(" nqamakwe");
this._fromProviders.push(" nqadu");
this._fromProviders.push(" ngwane");
this._fromProviders.push(" ngqeleni");
this._fromProviders.push(" new-brighton");
this._fromProviders.push(" ncora");
this._fromProviders.push(" mqanduli");
this._fromProviders.push(" mount-frere");
this._fromProviders.push(" mount-ayliff");
this._fromProviders.push(" mncotsho");
this._fromProviders.push(" mnceba");
this._fromProviders.push(" mjanyana");
this._fromProviders.push(" middleton");
this._fromProviders.push(" middledrift");
this._fromProviders.push(" mgwalana");
this._fromProviders.push(" mgojweni");
this._fromProviders.push(" mdantsane");
this._fromProviders.push(" masincedane");
this._fromProviders.push(" mahlungulu");
this._fromProviders.push(" maclear");
this._fromProviders.push(" maclear");
this._fromProviders.push(" macleantown");
this._fromProviders.push(" lusikisiki");
this._fromProviders.push(" louterwater");
this._fromProviders.push(" loerie");
this._fromProviders.push(" libode");
this._fromProviders.push(" lanti");
this._fromProviders.push(" kwanyana");
this._fromProviders.push(" kwanobuhle");
this._fromProviders.push(" krakeelrivier");
this._fromProviders.push(" komga");
this._fromProviders.push(" klipplaat");
this._fromProviders.push(" kleinpoort");
this._fromProviders.push(" king-williams-town");
this._fromProviders.push(" kenton-on-sea");
this._fromProviders.push(" kentani");
this._fromProviders.push(" keiskammahoek");
this._fromProviders.push(" kei-road");
this._fromProviders.push(" kareedouw");
this._fromProviders.push(" kareedouw");
this._fromProviders.push(" kamastone");
this._fromProviders.push(" joubertina");
this._fromProviders.push(" jeffreys-bay");
this._fromProviders.push(" jansenville");
this._fromProviders.push(" indwe");
this._fromProviders.push(" idutywa");
this._fromProviders.push(" ida");
this._fromProviders.push(" humansdorp");
this._fromProviders.push(" hogsback");
this._fromProviders.push(" hofmeyr");
this._fromProviders.push(" hankey");
this._fromProviders.push(" hamburg");
this._fromProviders.push(" halseton");
this._fromProviders.push(" hackney");
this._fromProviders.push(" gonubie");
this._fromProviders.push(" gelvandale");
this._fromProviders.push(" fort-murray");
this._fromProviders.push(" flagstaff");
this._fromProviders.push(" engcobo");
this._fromProviders.push(" elliotdale");
this._fromProviders.push(" elliot");
this._fromProviders.push(" despatch");
this._fromProviders.push(" debe-nek");
this._fromProviders.push(" cookhouse");
this._fromProviders.push(" cofimvaba");
this._fromProviders.push(" coega");
this._fromProviders.push(" clarkebury");
this._fromProviders.push(" cathcart");
this._fromProviders.push(" cala");
this._fromProviders.push(" bongweni");
this._fromProviders.push(" bolotwa");
this._fromProviders.push(" boesmansriviermond");
this._fromProviders.push(" bizana");
this._fromProviders.push(" bethelsdorp");
this._fromProviders.push(" berlin");
this._fromProviders.push(" bedford");
this._fromProviders.push(" bathurst");
this._fromProviders.push(" askeaton");
this._fromProviders.push(" alicedale");
this._fromProviders.push(" alexandria");
this._fromProviders.push(" adendorp");
this._fromProviders.push(" addo");
this._fromProviders.push(" aberdeen");
this._fromProviders.push(" bagqozini");
this._fromProviders.push(" berlin-south");
this._fromProviders.push(" boardwalk");
this._fromProviders.push(" california");
this._fromProviders.push(" cape-st-francis");
this._fromProviders.push(" cawood");
this._fromProviders.push(" clarendon-marine");
this._fromProviders.push(" colchester");
this._fromProviders.push(" debenek");
this._fromProviders.push(" dumabenshiya");
this._fromProviders.push(" eastern-cape");
this._fromProviders.push(" estadeal");
this._fromProviders.push(" ezibeleni");
this._fromProviders.push(" gambleville");
this._fromProviders.push(" goodwin-park");
this._fromProviders.push(" gqebera");
this._fromProviders.push(" grahamstown-north");
this._fromProviders.push(" igoda");
this._fromProviders.push(" jersey-valley");
this._fromProviders.push(" joe-slovo-camp");
this._fromProviders.push(" kadwezi");
this._fromProviders.push(" khayalethu");
this._fromProviders.push(" khayelitsha");
this._fromProviders.push(" kommadagga");
this._fromProviders.push(" kwazakhele");
this._fromProviders.push(" linton-grange");
this._fromProviders.push(" long-hope");
this._fromProviders.push(" ludome");
this._fromProviders.push(" mabaleni");
this._fromProviders.push(" machibi");
this._fromProviders.push(" makwantini");
this._fromProviders.push(" mbizana");
this._fromProviders.push(" mbolompeni");
this._fromProviders.push(" misgund");
this._fromProviders.push(" moffat-place");
this._fromProviders.push(" motherwell");
this._fromProviders.push(" msobomvu");
this._fromProviders.push(" mthatha");
this._fromProviders.push(" ndabakazi");
this._fromProviders.push(" new-park");
this._fromProviders.push(" ngcelwane");
this._fromProviders.push(" ngozi");
this._fromProviders.push(" ngxakaza");
this._fromProviders.push(" nomvalo");
this._fromProviders.push(" nonkululeko");
this._fromProviders.push(" nonzwakazi");
this._fromProviders.push(" noupoort");
this._fromProviders.push(" nqutyana");
this._fromProviders.push(" ntabankulu");
this._fromProviders.push(" overbaakens");
this._fromProviders.push(" phantsi-kwentaba");
this._fromProviders.push(" port-st-johns");
this._fromProviders.push(" rabula");
this._fromProviders.push(" saltville");
this._fromProviders.push(" sandringham");
this._fromProviders.push(" sigingqini");
this._fromProviders.push(" siphiwo-mazwayi");
this._fromProviders.push(" sitofile");
this._fromProviders.push(" south-seas");
this._fromProviders.push(" st-francis-bay");
this._fromProviders.push(" swartkops");
this._fromProviders.push(" thornhill");
this._fromProviders.push(" tshabo-Eastern Cape'");
this._fromProviders.push(" tshabo-2");
this._fromProviders.push(" tshabo-3");
this._fromProviders.push(" tshonya");
this._fromProviders.push(" tyoksvalley");
this._fromProviders.push(" vulindlela-heights");

this._fromProviders.push(" vulindlelahoogte");
this._fromProviders.push(" walmer");
this._fromProviders.push(" witmos");
this._fromProviders.push(" zwide");
this._fromProviders.push(" willowmore");
this._fromProviders.push(" dordrecht");
this._fromProviders.push(" alice");
this._fromProviders.push(" molteno");
this._fromProviders.push(" kirkwood");
this._fromProviders.push(" whittlesea");
this._fromProviders.push(" adelaide");
this._fromProviders.push(" somerset-east");
this._fromProviders.push(" port-alfred");
this._fromProviders.push(" middelburg");
this._fromProviders.push(" lady-frere");
this._fromProviders.push(" cradock");
this._fromProviders.push(" butterworth");
this._fromProviders.push(" stutterheim");
this._fromProviders.push(" fort-beaufort");
this._fromProviders.push(" graaff-reinet");
this._fromProviders.push(" umtata");
this._fromProviders.push(" grahamstown");
this._fromProviders.push(" queenstown");
this._fromProviders.push(" bhisho");
this._fromProviders.push(" uitenhage");
this._fromProviders.push(" east-london");
this._fromProviders.push(" port-elizabeth");
this._fromProviders.push(" witsieshoek");
this._fromProviders.push(" wepener");
this._fromProviders.push(" warden");
this._fromProviders.push(" vierfontein");
this._fromProviders.push(" verkeerdevlei");
this._fromProviders.push(" tweespruit");
this._fromProviders.push(" tweeling");
this._fromProviders.push(" trompsburg");
this._fromProviders.push(" thaba-phatshawa");
this._fromProviders.push(" steynsrus");
this._fromProviders.push(" springfontein");
this._fromProviders.push(" steunmekaar");
this._fromProviders.push(" smithfield");
this._fromProviders.push(" rouxville");
this._fromProviders.push(" rosendal");
this._fromProviders.push(" reddersburg");
this._fromProviders.push(" philippolis");
this._fromProviders.push(" petrus-steyn");
this._fromProviders.push(" petrusburg");
this._fromProviders.push(" paul-roux");
this._fromProviders.push(" palmietfontein");
this._fromProviders.push(" oranjeville");
this._fromProviders.push(" odendaalsrus");
this._fromProviders.push(" marseilles");
this._fromProviders.push(" luckhoff");
this._fromProviders.push(" lindley");
this._fromProviders.push(" koffiefontein");
this._fromProviders.push(" kestell");
this._fromProviders.push(" jagersfontein");
this._fromProviders.push(" hobhouse");
this._fromProviders.push(" hertzogville");
this._fromProviders.push(" fouriesburg");
this._fromProviders.push(" ficksburg");
this._fromProviders.push(" fauresmith");
this._fromProviders.push(" excelsior");
this._fromProviders.push(" edenville");
this._fromProviders.push(" edenburg");
this._fromProviders.push(" dewetsdorp");
this._fromProviders.push(" dealesville");
this._fromProviders.push(" cornelia");
this._fromProviders.push(" clarens");
this._fromProviders.push(" bultfontein");
this._fromProviders.push(" botshabelo");
this._fromProviders.push(" bloemspruit");
this._fromProviders.push(" bethulie");
this._fromProviders.push(" arlington");
this._fromProviders.push(" aliwal-north");
this._fromProviders.push(" bambanani");
this._fromProviders.push(" barkly-east");
this._fromProviders.push(" bensonvale");
this._fromProviders.push(" blikana");
this._fromProviders.push(" bohlokong");
this._fromProviders.push(" burgersdorp");
this._fromProviders.push(" colesberg");
this._fromProviders.push(" coville");
this._fromProviders.push(" dikgakeng");
this._fromProviders.push(" diqhobong");
this._fromProviders.push(" dulcies-nek");
this._fromProviders.push(" falckvlei");
this._fromProviders.push(" free-state");
this._fromProviders.push(" ga-rapulana");
this._fromProviders.push(" ga-sehunelo");
this._fromProviders.push(" geduldpan");
this._fromProviders.push(" betglen-harmony-centralhulie");
this._fromProviders.push(" herschel");
this._fromProviders.push(" hoita");
this._fromProviders.push(" intabazwe");
this._fromProviders.push(" jamestown");
this._fromProviders.push(" jozannashoek");
this._fromProviders.push(" kagisanong");
this._fromProviders.push(" knapdaar");
this._fromProviders.push(" kroonpark");
this._fromProviders.push(" kwandofela");
this._fromProviders.push(" lady-grey");
this._fromProviders.push(" lengau");
this._fromProviders.push(" makaota");
this._fromProviders.push(" mangaung");
this._fromProviders.push(" mavelebayi");
this._fromProviders.push(" merafong");
this._fromProviders.push(" mokodumela");
this._fromProviders.push(" motsethabong");
this._fromProviders.push(" phomolong");
this._fromProviders.push(" poelong");
this._fromProviders.push(" quimera");
this._fromProviders.push(" ramosili");
this._fromProviders.push(" rosskent");
this._fromProviders.push(" selosesha");
this._fromProviders.push(" sipambo-basin");
this._fromProviders.push(" sterkspruit");
this._fromProviders.push(" steynpan");
this._fromProviders.push(" tele-bridge");
this._fromProviders.push(" teresa");
this._fromProviders.push(" thabong-east");
this._fromProviders.push(" theronville");
this._fromProviders.push(" tikwana");
this._fromProviders.push(" tyinindini");
this._fromProviders.push(" venterstad");
this._fromProviders.push(" westminster");
this._fromProviders.push(" wiegandia");
this._fromProviders.push(" vredefort");
this._fromProviders.push(" ventersburg");
this._fromProviders.push(" marquard");
this._fromProviders.push(" winburg");
this._fromProviders.push(" villiers");
this._fromProviders.push(" koppies");
this._fromProviders.push(" brandfort");
this._fromProviders.push(" clocolan");
this._fromProviders.push(" deneysville");
this._fromProviders.push(" zastron");
this._fromProviders.push(" vrede");
this._fromProviders.push(" reitz");
this._fromProviders.push(" ladybrand");
this._fromProviders.push(" hennenman");
this._fromProviders.push(" allanridge");
this._fromProviders.push(" theunissen");
this._fromProviders.push(" harrismith");
this._fromProviders.push(" frankfort");
this._fromProviders.push(" thaba-nchu");
this._fromProviders.push(" senekal");
this._fromProviders.push(" wesselsbron");
this._fromProviders.push(" viljoenskroon");
this._fromProviders.push(" heilbron");
this._fromProviders.push(" parys");
this._fromProviders.push(" bothaville");
this._fromProviders.push(" sasolburg");
this._fromProviders.push(" bethlehem");
this._fromProviders.push(" phuthaditjhaba");
this._fromProviders.push(" kroonstad");
this._fromProviders.push(" virginia");
this._fromProviders.push(" welkom");
this._fromProviders.push(" bloemfontein");
this._fromProviders.push(" walkerville");
this._fromProviders.push(" springs");
this._fromProviders.push(" soshanguve");
this._fromProviders.push(" sebokeng");
this._fromProviders.push(" rosslyn");
this._fromProviders.push(" roshnee");
this._fromProviders.push(" rivonia");;
this._fromProviders.push(" randburg");
this._fromProviders.push(" primrose");
this._fromProviders.push(" muldersdrif");
this._fromProviders.push(" moroka");
this._fromProviders.push(" mohlakeng");
this._fromProviders.push(" meyerton");
this._fromProviders.push(" mamelodi");
this._fromProviders.push(" laudium");
this._fromProviders.push(" kwathema");
this._fromProviders.push(" kromdraai");
this._fromProviders.push(" kempton-park");
this._fromProviders.push(" germiston");
this._fromProviders.push(" edenvale");
this._fromProviders.push(" devon");
this._fromProviders.push(" de-deur");
this._fromProviders.push(" bedfordview");
this._fromProviders.push(" alberton");
this._fromProviders.push(" pyramid");
this._fromProviders.push(" akasia");
this._fromProviders.push(" ga-rankuwa");
this._fromProviders.push(" graceland");
this._fromProviders.push(" greenstone-hill");
this._fromProviders.push(" jukskeipark");
this._fromProviders.push(" julies-park");
this._fromProviders.push(" kagiso");
this._fromProviders.push(" kempton-gate");
this._fromProviders.push(" klopperpark");
this._fromProviders.push(" kocksvlei");
this._fromProviders.push(" koolfontein");
this._fromProviders.push(" kragbron");
this._fromProviders.push(" kruinhof");
this._fromProviders.push(" kwaxuma");
this._fromProviders.push(" lenasia-ntcentren");
this._fromProviders.push(" lindekuhle");
this._fromProviders.push(" lynn-east");
this._fromProviders.push(" mafatsana");
this._fromProviders.push(" magalies-view");
this._fromProviders.push(" magalieskruin");
this._fromProviders.push(" marlboro");
this._fromProviders.push(" marshalltown");
this._fromProviders.push(" masitshaba");
this._fromProviders.push(" masoheng");
this._fromProviders.push(" medunsa");
this._fromProviders.push(" meldene");
this._fromProviders.push(" midvaal");
this._fromProviders.push(" moiletswane");
this._fromProviders.push(" montanapark");
this._fromProviders.push(" montpark");
this._fromProviders.push(" moot");
this._fromProviders.push(" morula");
this._fromProviders.push(" northwold");
this._fromProviders.push(" odin-park");
this._fromProviders.push(" orange-farm");
this._fromProviders.push(" Braamfontein");
this._fromProviders.push(" orange-grove");
this._fromProviders.push(" panfontein");
this._fromProviders.push(" paulshof");
this._fromProviders.push(" philip-nel-park witsieshoek");
this._fromProviders.push(" protea-gardens");
this._fromProviders.push(" protea-glen");
this._fromProviders.push(" rabie-ridge");
this._fromProviders.push(" randpark-ridge");
this._fromProviders.push(" randvaal");
this._fromProviders.push(" residensia");
this._fromProviders.push(" rietvallei-park");
this._fromProviders.push(" riversands");
this._fromProviders.push(" roodeplaat");
this._fromProviders.push(" roosevelt-park");
this._fromProviders.push(" sasolburg");
this._fromProviders.push(" tamboville");
this._fromProviders.push(" vaaldam");
this._fromProviders.push(" zz-tba");
this._fromProviders.push(" modderfontein");
this._fromProviders.push(" sandton");
this._fromProviders.push(" cullinan");
this._fromProviders.push(" bronkhorstspruit");
this._fromProviders.push(" heidelberg");
this._fromProviders.push(" mabopane");
this._fromProviders.push(" randfontein");
this._fromProviders.push(" nigel");
this._fromProviders.push(" westonaria");
this._fromProviders.push(" midrand");
this._fromProviders.push(" brakpan");
this._fromProviders.push(" centurion");
this._fromProviders.push(" vanderbijlpark");
this._fromProviders.push(" krugersdorp");
this._fromProviders.push(" roodepoort");
this._fromProviders.push(" boksburg");
this._fromProviders.push(" vereeniging");
this._fromProviders.push(" tembisa");
this._fromProviders.push(" benoni");
this._fromProviders.push(" pretoria");
this._fromProviders.push(" soweto");
this._fromProviders.push(" johannesburg");
this._fromProviders.push(" winterton");
this._fromProviders.push(" winklespruit");
this._fromProviders.push(" westville");
this._fromProviders.push(" westbrook");
this._fromProviders.push(" wasbank");
this._fromProviders.push(" wartburg");
this._fromProviders.push(" verulam");
this._fromProviders.push(" vaalkop");
this._fromProviders.push(" uvongo-beach");
this._fromProviders.push(" underberg");
this._fromProviders.push(" umzumbe");
this._fromProviders.push(" umtentweni");
this._fromProviders.push(" umlazi");
this._fromProviders.push(" umhlanga-rocks");
this._fromProviders.push(" umbumbulu");
this._fromProviders.push(" umbogintwini");
this._fromProviders.push(" uitval");
this._fromProviders.push(" ubombo");
this._fromProviders.push(" tugela-ferry");
this._fromProviders.push(" shelly-beach");
this._fromProviders.push(" sheffield-beach");
this._fromProviders.push(" shakaskraal");
this._fromProviders.push(" salt-rock");
this._fromProviders.push(" saint-lucia-estuary");
this._fromProviders.push(" richmond");
this._fromProviders.push(" queensburgh");
this._fromProviders.push(" port-edward");
this._fromProviders.push(" pongola");
this._fromProviders.push(" pomeroy");
this._fromProviders.push(" pinetown");
this._fromProviders.push(" phoenix");
this._fromProviders.push(" paulpietersburg");
this._fromProviders.push(" ozwatini");
this._fromProviders.push(" osizweni");
this._fromProviders.push(" nqutu");
this._fromProviders.push(" nqabeni");
this._fromProviders.push(" nongoma");
this._fromProviders.push(" nkandla");
this._fromProviders.push(" new-german");
this._fromProviders.push(" ndwedwe");
this._fromProviders.push(" munster");
this._fromProviders.push(" mtunzini");
this._fromProviders.push(" mtubatuba");
this._fromProviders.push(" mount-edgecombe");
this._fromProviders.push(" mkuze");
this._fromProviders.push(" mid-illovo");
this._fromProviders.push(" merrivale");
this._fromProviders.push(" melmoth");
this._fromProviders.push(" mbazwana");
this._fromProviders.push(" matatiele");
this._fromProviders.push(" mariannhill");
this._fromProviders.push(" mapumulo");
this._fromProviders.push(" malvern");
this._fromProviders.push(" maidstone");
this._fromProviders.push(" mahlabatini");
this._fromProviders.push(" magabeni");
this._fromProviders.push(" ladysmith");
this._fromProviders.push(" kwambonambi");
this._fromProviders.push(" kwamashu");
this._fromProviders.push(" kwaceza");
this._fromProviders.push(" kranskop");
this._fromProviders.push(" kloof");
this._fromProviders.push(" jozini");
this._fromProviders.push(" izingolweni");
this._fromProviders.push(" ixopo");
this._fromProviders.push(" ingwavuma");
this._fromProviders.push(" inanda");
this._fromProviders.push(" impendle");
this._fromProviders.push(" illovo-beach");
this._fromProviders.push(" ifafa-beach");
this._fromProviders.push(" hluhluwe");
this._fromProviders.push(" hlobane");
this._fromProviders.push(" hlabisa");
this._fromProviders.push(" himeville");
this._fromProviders.push(" hilton");
this._fromProviders.push(" hillcrest");
this._fromProviders.push(" highflats");
this._fromProviders.push(" hibberdene");
this._fromProviders.push(" harding");
this._fromProviders.push(" hammarsdale");
this._fromProviders.push(" golela");
this._fromProviders.push(" gingindlovu");
this._fromProviders.push(" gillitts");
this._fromProviders.push(" estcourt");
this._fromProviders.push(" emmaus");
this._fromProviders.push(" elandskop");
this._fromProviders.push(" edendale");
this._fromProviders.push(" doonside");
this._fromProviders.push(" donnybrook");
this._fromProviders.push(" darnall");
this._fromProviders.push(" dannhauser");
this._fromProviders.push(" dalton");
this._fromProviders.push(" creighton");
this._fromProviders.push(" colenso");
this._fromProviders.push(" cato-ridge");
this._fromProviders.push(" bulwer");
this._fromProviders.push(" bergville");
this._fromProviders.push(" anerley");
this._fromProviders.push(" amatikulu");
this._fromProviders.push(" amanzimtoti");
this._fromProviders.push(" ballito");
this._fromProviders.push(" amajuba");
this._fromProviders.push(" blood-river");
this._fromProviders.push(" bombay-road");
this._fromProviders.push(" bothas-hill");
this._fromProviders.push(" chatsworth");
this._fromProviders.push(" clernaville");
this._fromProviders.push(" coffee-farm");
this._fromProviders.push(" desainaga");
this._fromProviders.push(" dormerton");
this._fromProviders.push(" dumbe");
this._fromProviders.push(" durban-north");
this._fromProviders.push(" emondlo");
this._fromProviders.push(" emphithi");
this._fromProviders.push(" eston");
this._fromProviders.push(" ezakheni");
this._fromProviders.push(" harrismith");
this._fromProviders.push(" hemuhemu");
this._fromProviders.push(" hoha");
this._fromProviders.push(" imdumeni");
this._fromProviders.push(" isipingo");
this._fromProviders.push(" jacobs");
this._fromProviders.push(" kaarkloof");
this._fromProviders.push(" kwadlangezwa");
this._fromProviders.push(" kwamkhonto");
this._fromProviders.push(" kwangwanase");
this._fromProviders.push(" kwazimele");
this._fromProviders.push(" kwazulunatal");
this._fromProviders.push(" lamontville");
this._fromProviders.push(" magadla");
this._fromProviders.push(" maluti");
this._fromProviders.push(" manaba-beach");
this._fromProviders.push(" mandeni");
this._fromProviders.push(" manzana");
this._fromProviders.push(" 'marble-ray");
this._fromProviders.push(" mayville");
this._fromProviders.push(" mbeka");
this._fromProviders.push(" mbiyo");
this._fromProviders.push(" mehlomnyama");
this._fromProviders.push(" mobeni");
this._fromProviders.push(" mount-fletcher");
this._fromProviders.push(" mphophomeni");
this._fromProviders.push(" nagina");
this._fromProviders.push(" ncalu");
this._fromProviders.push(" ncotshane");
this._fromProviders.push(" nkumane");
this._fromProviders.push(" nkwazi");
this._fromProviders.push(" northdene");
this._fromProviders.push(" nottingham-rd");
this._fromProviders.push(" ntabamhlophe");
this._fromProviders.push(" ntokozweni");
this._fromProviders.push(" pennington");
this._fromProviders.push(" rossburgh");
this._fromProviders.push(" shallcross");
this._fromProviders.push(" st-lucia-estuary");
this._fromProviders.push(" st-wendolins");
this._fromProviders.push(" steadville");
this._fromProviders.push(" taylors-halt");
this._fromProviders.push(" umhlali");
this._fromProviders.push(" umkomaas-valley");
this._fromProviders.push(" umtata");
this._fromProviders.push(" umzimkhulu");
this._fromProviders.push(" wiggins");
this._fromProviders.push(" yellowwood-park");
this._fromProviders.push(" zinkwazi");
this._fromProviders.push(" utrecht");
this._fromProviders.push(" mooirivier");
this._fromProviders.push(" glencoe");
this._fromProviders.push(" greytown");
this._fromProviders.push(" ekuvukeni");
this._fromProviders.push(" eshowe");
this._fromProviders.push(" umkomaas");
this._fromProviders.push(" ulundi");
this._fromProviders.push(" scottburgh");
this._fromProviders.push(" kokstad");
this._fromProviders.push(" empangeni");
this._fromProviders.push(" howick");
this._fromProviders.push(" margate");
this._fromProviders.push(" esikhawini");
this._fromProviders.push(" stanger");
this._fromProviders.push(" dundee");
this._fromProviders.push(" vryheid");
this._fromProviders.push(" richards-bay");
this._fromProviders.push(" newcastle");
this._fromProviders.push(" pietermaritzburg");
this._fromProviders.push(" durban");
this._fromProviders.push(" zebediela");
this._fromProviders.push(" vaalwater");
this._fromProviders.push(" sibasa");
this._fromProviders.push(" mutale");
this._fromProviders.push(" modjadji");
this._fromProviders.push(" letaba");
this._fromProviders.push(" jane-furse");
this._fromProviders.push(" hoedspruit");
this._fromProviders.push(" gravelotte");
this._fromProviders.push(" dendron");
this._fromProviders.push(" bochum");
this._fromProviders.push(" alldays");
this._fromProviders.push(" bela-bela");
this._fromProviders.push(" lephalale");
this._fromProviders.push(" makhado");
this._fromProviders.push(" malamulele");
this._fromProviders.push(" modimolle");
this._fromProviders.push(" modjadjiskloof");
this._fromProviders.push(" mokopane");
this._fromProviders.push(" musina");
this._fromProviders.push(" vuwani");
this._fromProviders.push(" thabazimbi");
this._fromProviders.push(" gakgapane");
this._fromProviders.push(" tzaneen");
this._fromProviders.push(" thohoyandou");
this._fromProviders.push(" giyani");
this._fromProviders.push(" louis-trichardt");
this._fromProviders.push(" polokwane");
this._fromProviders.push(" wakkerstroom");
this._fromProviders.push(" steelpoort");
this._fromProviders.push(" skukuza");
this._fromProviders.push(" skilpadfontein");
this._fromProviders.push(" shongwe-mission");
this._fromProviders.push(" sakhile");
this._fromProviders.push(" sabie");
this._fromProviders.push(" rietkuil");
this._fromProviders.push(" ogies");
this._fromProviders.push(" nsikazi");
this._fromProviders.push(" marble-hall");
this._fromProviders.push(" malelane");
this._fromProviders.push(" machadodorp");
this._fromProviders.push(" leslie");
this._fromProviders.push(" kwalugedlane");
this._fromProviders.push(" hazyview");
this._fromProviders.push(" groblersdal");
this._fromProviders.push(" graskop");
this._fromProviders.push(" evander");
this._fromProviders.push(" enyamazaneni");
this._fromProviders.push(" empumalanga");
this._fromProviders.push(" carolina");
this._fromProviders.push(" burgersfort");
this._fromProviders.push(" bosbokrand");
this._fromProviders.push(" blinkpan");
this._fromProviders.push(" bethalrand");
this._fromProviders.push(" badplaas");
this._fromProviders.push(" amsterdam");
this._fromProviders.push(" amersfoort");
this._fromProviders.push(" bamokgoko");
this._fromProviders.push(" batubatse");
this._fromProviders.push(" boitekong");
this._fromProviders.push(" boleu");
this._fromProviders.push(" brits");
this._fromProviders.push(" chromite");
this._fromProviders.push(" devon");
this._fromProviders.push(" dibasabophelo");
this._fromProviders.push(" driekop");
this._fromProviders.push(" dundonald");
this._fromProviders.push(" ekangala");
this._fromProviders.push(" ellisras");
this._fromProviders.push(" ga-rankuwa");
this._fromProviders.push(" hammanskraal");
this._fromProviders.push(" hluvukani");
this._fromProviders.push(" kabokweni");
this._fromProviders.push(" koster");
this._fromProviders.push(" kwaguqa");
this._fromProviders.push(" kwamhlanga");
this._fromProviders.push(" kwazamokuhle");
this._fromProviders.push(" leeupoort");
this._fromProviders.push(" lephalale");
this._fromProviders.push(" lethabong");
this._fromProviders.push(" letlhabile");
this._fromProviders.push(" mabopane");
this._fromProviders.push(" mafikeng");
this._fromProviders.push(" mahwelereng");
this._fromProviders.push(" malamulele");
this._fromProviders.push(" marikana");
this._fromProviders.push(" mbibane");
this._fromProviders.push(" mkhuhlu");
this._fromProviders.push(" mogwase");
this._fromProviders.push(" mooinooi");
this._fromProviders.push(" mokamole");
this._fromProviders.push(" mphe-batho");
this._fromProviders.push(" mpudulle");
this._fromProviders.push(" mpuluzi");
this._fromProviders.push(" mpumalanga");
this._fromProviders.push(" mutlestad");
this._fromProviders.push(" namakgale");
this._fromProviders.push(" nasaret");
this._fromProviders.push(" nebo");
this._fromProviders.push(" nelspruit-north");
this._fromProviders.push(" nkwe");
this._fromProviders.push(" nucam");
this._fromProviders.push(" nylpark");
this._fromProviders.push(" odinburg");
this._fromProviders.push(" penge");
this._fromProviders.push(" podiphatshwa");
this._fromProviders.push(" potgietersrus");
this._fromProviders.push(" pullens-hope");
this._fromProviders.push(" rantebeng");
this._fromProviders.push(" rayton");
this._fromProviders.push(" rebone");
this._fromProviders.push(" regorogile");
this._fromProviders.push(" roedtan");
this._fromProviders.push(" rust-de-winter");
this._fromProviders.push(" saulspoort");
this._fromProviders.push(" sekhukhune");
this._fromProviders.push(" settlers");
this._fromProviders.push(" soshanguve");
this._fromProviders.push(" sundra");
this._fromProviders.push(" swartklip");
this._fromProviders.push(" thabazimbi");
this._fromProviders.push(" thohoyandou");
this._fromProviders.push(" thulamahashe");
this._fromProviders.push(" thulwe");
this._fromProviders.push(" vaalwater");
this._fromProviders.push(" van-dyksdrif");
this._fromProviders.push(" ximhungwe");
this._fromProviders.push(" xipame");
this._fromProviders.push(" zz-tba");
this._fromProviders.push(" belfast");
this._fromProviders.push(" breyten");
this._fromProviders.push(" kriel");
this._fromProviders.push(" hendrina");
this._fromProviders.push(" white-river");
this._fromProviders.push(" secunda");
this._fromProviders.push(" komatipoort");
this._fromProviders.push(" lydenburg");
this._fromProviders.push(" siyabuswa");
this._fromProviders.push(" ermelo");
this._fromProviders.push(" volksrust");
this._fromProviders.push(" balfour");
this._fromProviders.push(" standerton");
this._fromProviders.push(" piet-retief");
this._fromProviders.push(" delmas");
this._fromProviders.push(" nelspruit");
this._fromProviders.push(" embalenhle");
this._fromProviders.push(" middelburg");
this._fromProviders.push(" witbank");
this._fromProviders.push(" windsorton");
this._fromProviders.push(" williston");
this._fromProviders.push(" vanderkloof");
this._fromProviders.push(" ulco");
this._fromProviders.push(" sutherland");
this._fromProviders.push(" strydenburg");
this._fromProviders.push(" rietfontein");
this._fromProviders.push(" postmasburg");
this._fromProviders.push(" philipstown");
this._fromProviders.push(" petrusville");
this._fromProviders.push(" olifantshoek");
this._fromProviders.push(" niekerkshoop");
this._fromProviders.push(" marydale");
this._fromProviders.push(" mancorp-mine");
this._fromProviders.push(" lime-acres");
this._fromProviders.push(" kenhardt");
this._fromProviders.push(" keimoes");
this._fromProviders.push(" kakamas");
this._fromProviders.push(" hotazel");
this._fromProviders.push(" hopetown");
this._fromProviders.push(" hartswater");
this._fromProviders.push(" grootdrink");
this._fromProviders.push(" groblershoop");
this._fromProviders.push(" griekwastad");
this._fromProviders.push(" douglas");
this._fromProviders.push(" dibeng");
this._fromProviders.push(" delportshoop");
this._fromProviders.push(" britstown");
this._fromProviders.push(" brandvlei");
this._fromProviders.push(" askham");
this._fromProviders.push(" vioolsdrif");
this._fromProviders.push(" steinkopf");
this._fromProviders.push(" port-nolloth");
this._fromProviders.push(" pofadder");
this._fromProviders.push(" pella");
this._fromProviders.push(" okiep");
this._fromProviders.push(" nieuwoudtville");
this._fromProviders.push(" nababeep");
this._fromProviders.push(" loeriesfontein");
this._fromProviders.push(" kotzeshoop");
this._fromProviders.push(" kleinsee");
this._fromProviders.push(" kamieskroon");
this._fromProviders.push(" garies");
this._fromProviders.push(" beaconsfield");
this._fromProviders.push(" alexander-bay");
this._fromProviders.push(" belmont");
this._fromProviders.push(" boshof");
this._fromProviders.push(" galeshewe");
this._fromProviders.push(" ganyesa");
this._fromProviders.push(" jacobsdal");
this._fromProviders.push(" jan-kempdorp");
this._fromProviders.push(" madibogo");
this._fromProviders.push(" magogong");
this._fromProviders.push(" mankurwane");
this._fromProviders.push(" mothibistat");
this._fromProviders.push(" northern-cape");
this._fromProviders.push(" pescodia");
this._fromProviders.push(" pomfret");
this._fromProviders.push(" pudimoe");
this._fromProviders.push(" reivilo");
this._fromProviders.push(" seseng");
this._fromProviders.push(" stella");
this._fromProviders.push(" taung");
this._fromProviders.push(" vredendal");
this._fromProviders.push(" vryburg");
this._fromProviders.push(" carnarvon");
this._fromProviders.push(" calvinia");
this._fromProviders.push(" kuruman");
this._fromProviders.push(" kathu");
this._fromProviders.push(" ritchie");
this._fromProviders.push(" danielskuil");
this._fromProviders.push(" springbok");
this._fromProviders.push(" prieska");
this._fromProviders.push(" barkly-west");
this._fromProviders.push(" warrenton");
this._fromProviders.push(" de-aar");
this._fromProviders.push(" upington");
this._fromProviders.push(" kimberley");
this._fromProviders.push(" ventersdorp");
this._fromProviders.push(" swartruggens");
this._fromProviders.push(" sannieshof");
this._fromProviders.push(" ottosdal");
this._fromProviders.push(" montshiwa");
this._fromProviders.push(" makwassie");
this._fromProviders.push(" mafikeng");
this._fromProviders.push(" madikwe");
this._fromProviders.push(" madibogo");
this._fromProviders.push(" leeudoringstad");
this._fromProviders.push(" kokosi");
this._fromProviders.push(" jouberton");
this._fromProviders.push(" itsoseng");
this._fromProviders.push(" hartbeespoort");
this._fromProviders.push(" hartbeesfontein");
this._fromProviders.push(" groot-marico");
this._fromProviders.push(" delareyville");
this._fromProviders.push(" coligny");
this._fromProviders.push(" atamelang");
this._fromProviders.push(" carletonville");
this._fromProviders.push(" hekpoort");
this._fromProviders.push(" lebogang");
this._fromProviders.push(" lerato");
this._fromProviders.push(" radithuso");
this._fromProviders.push(" bloemhof");
this._fromProviders.push(" christiana");
this._fromProviders.push(" zeerust");
this._fromProviders.push(" wolmaransstad");
this._fromProviders.push(" fochville");
this._fromProviders.push(" lichtenburg");
this._fromProviders.push(" schweizer-reineke");
this._fromProviders.push(" mmabatho");
this._fromProviders.push(" stilfontein");
this._fromProviders.push(" potchefstroom");
this._fromProviders.push(" rustenburg");
this._fromProviders.push(" orkney");
this._fromProviders.push(" klerksdorp");
this._fromProviders.push(" wilderness");
this._fromProviders.push(" touwsrivier");
this._fromProviders.push(" stilbaai");
this._fromProviders.push(" sedgefield");
this._fromProviders.push(" riversdale");
this._fromProviders.push(" prince-albert");
this._fromProviders.push(" murraysburg");
this._fromProviders.push(" mossel-bay");
this._fromProviders.push(" montagu");
this._fromProviders.push(" laingsburg");
this._fromProviders.push(" ladismith");
this._fromProviders.push(" hartenbos");
this._fromProviders.push(" glentana");
this._fromProviders.push(" calitzdorp");
this._fromProviders.push(" bonnievale");
this._fromProviders.push(" barrydale");
this._fromProviders.push(" ashton");
this._fromProviders.push(" albertina");
this._fromProviders.push(" yzerfontein");
this._fromProviders.push(" wolseley");
this._fromProviders.push(" wellington");
this._fromProviders.push(" vredenburg");
this._fromProviders.push(" villiersdorp");
this._fromProviders.push(" velddrif");
this._fromProviders.push(" vanrhynsdorp");
this._fromProviders.push(" tulbagh");
this._fromProviders.push(" strandfontein");
this._fromProviders.push(" strand");
this._fromProviders.push(" robertson");
this._fromProviders.push(" pringle-bay");
this._fromProviders.push(" prince-alfred-hamlet");
this._fromProviders.push(" porterville");
this._fromProviders.push(" piketberg");
this._fromProviders.push(" paternoster");
this._fromProviders.push(" parow");
this._fromProviders.push(" paarl");
this._fromProviders.push(" noordhoek");
this._fromProviders.push(" napier");
this._fromProviders.push(" muizenberg");
this._fromProviders.push(" moorreesburg");
this._fromProviders.push(" mitchells-plain");
this._fromProviders.push(" milnerton");
this._fromProviders.push(" melkbosstrand");
this._fromProviders.push(" lutzville");
this._fromProviders.push(" langebaan");
this._fromProviders.push(" kuilsrivier");
this._fromProviders.push(" kraaifontein");
this._fromProviders.push(" kommetjie");
this._fromProviders.push(" houtbaai");
this._fromProviders.push(" hopefield");
this._fromProviders.push(" greyton");
this._fromProviders.push(" graafwater");
this._fromProviders.push(" goodwood");
this._fromProviders.push(" genadendal");
this._fromProviders.push(" gansbaai");
this._fromProviders.push(" franschhoek");
this._fromProviders.push(" eersterivier");
this._fromProviders.push(" durbanville");
this._fromProviders.push(" de-doorns");
this._fromProviders.push(" darling");
this._fromProviders.push(" clanwilliam");
this._fromProviders.push(" citrusdal");
this._fromProviders.push(" chatsworth");
this._fromProviders.push(" brackenfell");
this._fromProviders.push(" bitterfontein");
this._fromProviders.push(" bellville");
this._fromProviders.push(" belhar");
this._fromProviders.push(" aurora");
this._fromProviders.push(" somerset-west");
this._fromProviders.push(" rondebosch");
this._fromProviders.push(" bettys-bay");
this._fromProviders.push(" blaauwberg");
this._fromProviders.push(" blackheath");
this._fromProviders.push(" blue-downs");
this._fromProviders.push(" boggomsbaai");
this._fromProviders.push(" cape-agulhas");
this._fromProviders.push(" cederberg");
this._fromProviders.push(" elandsbay");
this._fromProviders.push(" elsies-river");
this._fromProviders.push(" fish-hoek");
this._fromProviders.push(" gordons-bay");
this._fromProviders.push(" grassy-park");
this._fromProviders.push(" jacobs-bay");
this._fromProviders.push(" kleinmond");
this._fromProviders.push(" lamberts-bay");
this._fromProviders.push(" lansdowne");
this._fromProviders.push(" malmesbury");
this._fromProviders.push(" matroosfontein");
this._fromProviders.push(" paarden-island");
this._fromProviders.push(" retreat");
this._fromProviders.push(" simons-town");
this._fromProviders.push(" st-helena-bay");
this._fromProviders.push(" zz-tba");
this._fromProviders.push(" caledon");
this._fromProviders.push(" swellendam");
this._fromProviders.push(" vredendal");
this._fromProviders.push(" bredasdorp");
this._fromProviders.push(" plettenberg-bay");
this._fromProviders.push(" hermanus");
this._fromProviders.push(" grabouw");
this._fromProviders.push(" ceres");
this._fromProviders.push(" beaufort-west");
this._fromProviders.push(" atlantis");
this._fromProviders.push(" knysna");
this._fromProviders.push(" saldanha");
this._fromProviders.push(" oudtshoorn");
this._fromProviders.push(" stellenbosch");
this._fromProviders.push(" worcester");
this._fromProviders.push(" george");
this._fromProviders.push(" cape-town");

	
    }

    ngOnInit(): void {
        // Init your component properties here.
        this._btnPrevious = this.page.getViewById('btnPrevious');
        this._btnNext = this.page.getViewById('btnNext');
        this._itemImageStepper1 = this.page.getViewById('itemImageStepper1');
        this._itemImageStepper2 = this.page.getViewById('itemImageStepper2');
        this._itemImageStepper3 = this.page.getViewById('itemImageStepper3');
        this._itemStepper1 = this.page.getViewById('itemStepper1');
        this._itemStepper2 = this.page.getViewById('itemStepper2');
        this._itemStepper3 = this.page.getViewById('itemStepper3');
        this._selectDateGridLayout = this.page.getViewById('selectDateGridLayout');
        this._overlayGridLayout = this.page.getViewById('overlayGridLayout');

        if (topmost().ios) {
            let navigationBar = topmost().ios.controller.navigationBar;
            navigationBar.translucent = false;
            navigationBar.setBackgroundImageForBarMetrics(UIImage.new(), UIBarMetrics.Default);
            navigationBar.shadowImage = UIImage.new();
        }

        if (isAndroid) {
            this.page.androidStatusBarBackground = new Color(BASE_COLOR);
        }
    }
    @ViewChild('myCommitDataForm',{static:false}) myCommitDataFormComp:RadDataFormComponent;


    onOpenSearchAirportTap(isFrom: boolean): void {
		const options: ModalDialogOptions = {
			viewContainerRef: this._vcRef,
			context: { isFrom },
			fullscreen: true
		};
/*
		this._modalService.showModal(SearchAirportComponent, options)
			.then((result: any) => {
				if (result.isFrom) {
                    this.album.pickup = result.airport.name;
				} else {
					this.album.destination = result.airport.name;
				}
            });
            */
    }

    public onTap(){
        this.myCommitDataFormComp.dataForm.commitAll();
    }

    save(){
		this.bookingService.save(this.booking);
        this.alert("Your booking was successfully created.");
        this.routerExtensions.navigate(["/search"], { clearHistory: false });
        //send message
        /*
        var twilio = require('twilio');
        var accountSid = 'ACfad9714f30a626f64fceb7297c7b3c63'; // Your Account SID from www.twilio.com/console
        var authToken = 'bc0d6dc69cb045cb262c92e8d3f7bd04';
        var client = new twilio(accountSid, authToken);
        client.messages.create({
            body: 'A trip booking has been made on the pakisha app using this number, reply yes to confirm',
            to: `${this.booking.cellno}`,  // Text this number
            from: '+27600702649' // From a valid Twilio number
        })
        .then((message) => console.log(message.sid));
        */
        

    }
    twilio(){

    }
    redirectDashboard(){
        this.routerExtensions.navigate(["/dashboard"], { clearHistory: false });
	}
	alert(message: string) {
        return alert({
            title: "pakisha",
            okButtonText: "OK",
            message: message
        });
	}
   

    ngAfterViewInit(): void {
        setTimeout(() => {
            let target = this._itemImageStepper1;
            target.animate({ opacity: 1, duration: this._animationDuration })
                .then(() => {
                    console.log('Animation Finished!');
                })
                .catch((e) => {
                    console.log(e.message);
                });
        }, 3200)
    }
    

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.showDrawer();
    }

    itemImageStepper1GoForward() {
        let translate: number = this._translate;
        let duration = this._animationDuration;
        let target = this._itemImageStepper1;
        let targetNext = this._itemImageStepper2;
        target.animate({ translate: { x: translate, y: 0 }, duration: duration })
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this._itemStepper2.className = CURRENT_STEP;
                this._itemStepper1.className = SUCCESSFUL_STEP;
                targetNext.animate({ opacity: 1, duration: duration })
            })
            .then(() => {
                this.currentStep++;
                //this.selectReturn = true;
                this.enableButtons();
                console.log('Animation Finished!');
            })
            .catch((e) => {
                console.log(e.message);
            });
    }

    itemImageStepper2GoForward() {
        let translate: number = this._translate;
        let duration = this._animationDuration;
        let target = this._itemImageStepper2;
        let targetNext = this._itemImageStepper3;
        target.animate({ translate: { x: translate, y: 0 }, duration: duration })
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this._itemStepper3.className = CURRENT_STEP;
                this._itemStepper2.className = SUCCESSFUL_STEP;
                targetNext.animate({ opacity: 1, duration: duration })
            })
            .then(() => {
                this.currentStep++;
                this.enableButtons();
                console.log("Animation finished");
            })
            .catch((e) => {
                console.log(e.message);
            });
    }

    itemImageStepper2GoForwardPreviousStepLeft() {
        let translate: number = this._translate;
        let target = this._itemImageStepper2;
        let duration = this._animationDuration;
        let targetNext = this._itemImageStepper3;
        target.animate({ rotate: 360, duration: this._animationDuration })
            .then(() => {
                target.rotate = 0;
                this.rotateItemImageStepper2 = 0;
            })
            .then(() => target.animate({ translate: { x: translate, y: 0 }, duration: duration }))
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this._itemStepper2.className = SUCCESSFUL_STEP;
                this._itemStepper3.className = CURRENT_STEP;
                targetNext.animate({ opacity: 1, duration: duration })
            })
            .then(() => {
                this.currentStep++;
                this.enableButtons();
                console.log("Animation finished");
            })
            .catch((e) => {
                console.log(e.message);
            });
    }

    itemImageStepper2BackwardPreviousStepRight() {
        let translate: number = this._translate;
        let duration = this._animationDuration;
        let target = this._itemImageStepper2;
        let targetPrevious = this._itemImageStepper1;

        target.animate({ rotate: 360, duration: this._animationDuration })
            .then(() => {
                target.rotate = 0;
                this.rotateItemImageStepper2 = 180;
            })
            .then(() => target.animate({ translate: { x: -translate, y: 0 }, duration: duration }))
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this.rotateItemImageStepper2 = 0;
                this._itemStepper2.className = DEFAULT_STEP;
                this._itemStepper1.className = CURRENT_STEP;
                this.currentStep--;
            })
            .then(() => targetPrevious.animate({ opacity: 1 }))
            .then(() => {
                this.enableButtons();
                console.log("Animation finished");
            })
            .catch((e) => {
                console.log(e.message);
            });
    }

    itemImageStepper2BackwardPreviousStepLeft() {
        let translate: number = this._translate;
        let duration = this._animationDuration;
        let target = this._itemImageStepper2;
        let targetPrevious = this._itemImageStepper1;
        target.animate({ translate: { x: -translate, y: 0 }, duration: duration })
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this.rotateItemImageStepper2 = 0;
                this._itemStepper2.className = DEFAULT_STEP;
                this._itemStepper1.className = CURRENT_STEP;
                this.currentStep--;
            })
            .then(() => targetPrevious.animate({ opacity: 1 }))
            .then(() => {
                this.enableButtons();
                console.log("Animation finished");
            })
            .catch((e) => {
                console.log(e.message);
            });
    }

    itemImageStepper3Backward() {
        let translate: number = this._translate;
        let duration = this._animationDuration;
        let target = this._itemImageStepper3;
        let targetPrevious = this._itemImageStepper2;
        target.animate({ rotate: 360, duration: duration })
            .then(() => {
                target.rotate = 0;
                this.rotateItemImageStepper3 = 180;
            })
            .then(() => target.animate({ translate: { x: -translate, y: 0 }, duration: duration }))
            .then(() => target.animate({ opacity: 0, duration: duration }))
            .then(() => target.animate({ translate: { x: 0, y: 0 }, duration: 0 }))
            .then(() => {
                this.rotateItemImageStepper3 = 0;
                this.rotateItemImageStepper2 = 180;
                this._itemStepper3.className = DEFAULT_STEP;
                this._itemStepper2.className = CURRENT_STEP;
                this.currentStep--;
            })
            .then(() => targetPrevious.animate({ opacity: 1, duration: duration }))
            .then(() => {
                // this.dataList = this.flightData.flightDepart;
                this.enableButtons();
                console.log("Animation finished");
            })
            .catch((e) => {
                console.log(e.message);
            });

    }
    logd(){
        this.booking = new Booking();
        this.booking.pickup = this.album.pickup;
        this.booking.destination= this.album.destination;
        this.booking.date = this.album.date;
        this.booking.time = this.album.time;
        this.booking.seats = this.album.seats;
        this.booking.age=this.album.age;
        this.booking.luggage=this.album.luggage;
        this.booking.cellno=this.album.cellno;
        this.booking.confirm=this.album.confirm;
/*
        var urlD ="https://autocomplete.geocoder.ls.hereapi.com/6.2/suggest.json";
        var apikeys ="XeSsSdC4XnVb95Y1gya-vATCp2LbIyAcQk0WAis2qX0";
        var params = '?'+'query='+encodeURIComponent(this.album.pickup)+'&beginHighlight='+encodeURIComponent('<mark>')+'&endHighlight='+encodeURIComponent('</mark>')+'&maxresults=1'+'&apiKey='+apikeys;
        request({
            url:urlD+params,
            method:"GET"
        }).then((response:HttpResponse)=>{
            var obj = response.content.toJSON();
            var objL = obj.label.stringify();
            //this._fromProviders.push(obj.label);
            this._fromProviders.push(objL);
            console.log(objL);
        },(e)=>{

        });*/
        
        console.log(this.album.pickup);
        console.log(this.album.destination);
        console.log(this.album.cellno);
        console.log(this.album.age);
        console.log(this.album.seats);
        console.log(this.album.time);
        console.log(this.album.confirm);
    }

    animateGoForward() {
        this.disableButtons();
        this.previousMovesTo = this.moveTo;
        this.moveTo = MoveTo.Right;

        switch (this.currentStep) {
            case 1: {
                this.itemImageStepper1GoForward();
                break;
            }
            case 2: {
                if (this.previousMovesTo === MoveTo.Left) {
                    this.itemImageStepper2GoForwardPreviousStepLeft();
                } else {
                    this.itemImageStepper2GoForward();
                }
                break;
            }
            default: {
                this.enableButtons();
                break;
            }
        }
    }

    animateBackward() {
        this.disableButtons();
        this.previousMovesTo = this.moveTo;
        this.moveTo = MoveTo.Left;
        switch (this.currentStep) {
            case 2: {
                if (this.previousMovesTo === MoveTo.Left && this.moveTo === MoveTo.Left) {
                    this.itemImageStepper2BackwardPreviousStepLeft();
                } else {
                    this.itemImageStepper2BackwardPreviousStepRight();
                }
                break;
            }
            case 3: {
                this.itemImageStepper3Backward();
                break;
            }
            default: {
                this.enableButtons();
                break;
            }
        }
    }

    enableButtons() {
        this._btnPrevious.isEnabled = true;
        this._btnNext.isEnabled = true;
    }

    disableButtons() {
        this._btnPrevious.isEnabled = false;
        this._btnNext.isEnabled = false;
    }

    // Select Date
    onOpenSelectDate(event) {
        this.isOnOpenDepartureDate = event;

        if (this.isOnOpenDepartureDate) {
            this.dateSelector = this.departureDate;
        } else {
            this.dateSelector = this.returnDate;
        }

        this._selectDateGridLayout.visibility = <any>Visibility.visible;
        this._selectDateGridLayout.className = 'select-date animate-bounceInUp-delay-0ms';
        this._overlayGridLayout.animate({ opacity: 0.5, duration: 300 });
    }

    onCloseSelectDate(isCancel: boolean) {
        if (!isCancel) {
            this.selectedDate = this.dateSelector;
            if (this.isOnOpenDepartureDate) {
                this.departureDate = this.dateSelector;
            } else {
                this.returnDate = this.dateSelector;
            }
        }

        this._selectDateGridLayout.className = 'select-date';
        this._overlayGridLayout.animate({ opacity: 0, duration: 300 })
            .then(() => {
                this._selectDateGridLayout.visibility = <any>Visibility.collapse;
            })
            .catch(() => {
            });
    }

    onDateChanged(args) {
        let date: Date = args.value;
        this.dateSelector = date;
    }

    get fromProviders(): Array<String> {
        return this._fromProviders;
    }
    
}
