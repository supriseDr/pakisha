import { Component, ElementRef, ViewChild } from "@angular/core";
import { alert, prompt } from "tns-core-modules/ui/dialogs";
import { Page } from "tns-core-modules/ui/page";
import { RouterExtensions } from "nativescript-angular/router";

import { User } from "../shared/user.model";
import { UserService } from "../shared/user.service";
import { KinveyModule } from "kinvey-nativescript-sdk/lib/angular";
import { error } from "@angular/compiler/src/util";
import { InternetConnectionService } from "../shared/services/internet-connection.service";

@Component({
    selector: "app-login",
    moduleId: module.id,
    templateUrl: "./login.component.html",
    styleUrls: ['./login.component.css']
})
export class LoginComponent {
    connectionStatus: boolean = true;
    connection$;
    isLoggingIn = true;
    loginError ="";
    username: string = "dsnnkosi@gmail.com";
    user: User;
    processing = false;
    @ViewChild("password", {static: false}) password: ElementRef;
    @ViewChild("confirmPassword", {static: false}) confirmPassword: ElementRef;

    constructor(private page: Page,private _internetConnection: InternetConnectionService, private userService: UserService, private routerExtensions: RouterExtensions) {
        this.page.actionBarHidden = true;
        this.user = new User();
        this.user.email = "Your email";
        this.user.password = "Your password";
    }

    toggleForm() {
        this.isLoggingIn = !this.isLoggingIn;
    }

    ngOnInit(): void {
        this.connection$ = this._internetConnection.connectionStatus$.subscribe(data => {
            this.connectionStatus = data.valueOf();
        });

        this.userService.registerLservice();
    }

    ngOnDestroy(): void {
        if (this.connection$)
            this.connection$.unsubscribe();
    }

    submit() {
        if (!this.user.email || !this.user.password) {
            this.alert("Please provide both an email address and password.");
            return;
        }

        this.processing = true;
        if (this.isLoggingIn) {
            this.login();
        } else {
            this.register();
        }
    }
    hasLoginErrors(){
        return !!this.loginError;
    }
    getLoginError(){
        return this.loginError;
    }

    login() {
        this.userService.login(this.user)
            .then(() => {
                this.processing = false;
                this.routerExtensions.navigate(["/nav"], { clearHistory: true });
            })
            .catch(error => {
                this.processing = false;
               // this.alert(error.message);
            });
    }

    register() {
        /*if (this.user.password != this.user.confirmPassword) {
            this.alert("Your passwords do not match.");
            return;
        }
        */
        this.userService.register(this.user)
            .then(() => {
                this.processing = false;
                this.alert("Your account was successfully created.");
                this.isLoggingIn = true;
                this.routerExtensions.navigate(["/home"], { clearHistory: true });
            })
            .catch((e) => {
                this.processing = false;
            });
    };
    
    forgotPassword() {
        prompt({
            title: "Forgot Password",
            message: "Enter the email address you used to register for Pakisha to reset your password.",
            inputType: "email",
            defaultText: "",
            okButtonText: "Ok",
            cancelButtonText: "Cancel"
        }).then((data) => {
            if (data.result) {
                this.userService.resetPassword(data.text.trim())
                    .then(() => {
                        this.alert("Your password was successfully reset. Please check your email for instructions on choosing a new password.");
                    }).catch(() => {
                       // this.alert("Unfortunately, an error occurred resetting your password.");
                    });
            }
        });
    }

    redirectActive(){
       // if (condition) {
         
           // this.routerExtensions.navigate(["/dashboard"], { clearHistory: true });    
       // }
    }
   
    /*
    forgotPassword() {
        prompt({
            title: "Forgot Password",
            message: "Enter the email address you used to register for pakisha app to reset your password.",
            inputType: "email",
            defaultText: "",
            okButtonText: "Ok",
            cancelButtonText: "Cancel"
        }).then((data) => {
            
            if (data.result) {
                //console.log(data.text.trim())
                this.userService.resetPassword(data.text.trim())
                    .then(() => {
                        this.alert("Your password was reset request was successful. Please check your email for instructions on choosing a new password.");
                    }).catch(() => {
                        this.alert("Unfortunately, an error occurred resetting your password.");
                    });
                    
            }
        });
    }*/
    
    

    focusPassword() {
        this.password.nativeElement.focus();
    }
    focusConfirmPassword() {
        if (!this.isLoggingIn) {
            this.confirmPassword.nativeElement.focus();
        }
    }

    alert(message: string) {
        return alert({
            title: "Pakisha",
            okButtonText: "OK",
            message: message
        });
    }

    logout() {
        this.userService.logout();
        this.routerExtensions.navigate(["/login"], { clearHistory: true });
    }

    //redirect
    redirectAct(){
       if(this.userService.activeUser()!==null){
        this.routerExtensions.navigate(["/home"], { clearHistory: true });
       }
    }
    
    //Offline State

}

