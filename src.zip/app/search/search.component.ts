/*import { Component, OnInit, ViewChild, ElementRef} from "@angular/core";
import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import * as app from "tns-core-modules/application";
import { registerElement } from "nativescript-angular/element-registry";
import { CardView } from "nativescript-cardview";
registerElement("CardView", () => CardView);

import { NavigationEnd, Router } from "@angular/router";
import { RadSideDrawerComponent, SideDrawerType } from "nativescript-ui-sidedrawer/angular";
//import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import { RouterExtensions } from "nativescript-angular/router";
import { filter } from "rxjs/operators";
import { Booking } from "../shared/booking/booking.model";
import { BookingService } from "../shared/booking/booking.service";
import  {UserService} from "../shared/user.service";
import { Page } from "tns-core-modules/ui/page";

registerElement("CardView", () => CardView);

@Component({
    selector: "Search",
    templateUrl: "./search.component.html",
    styleUrls: ['./search.component.css']

})
export class SearchComponent implements OnInit {

    constructor() {
        // Use the component constructor to inject providers.
    }

    ngOnInit(): void {
        // Init your component properties here.
    }

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.showDrawer();
    }
}
*/
import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { RadSideDrawerComponent, SideDrawerType } from "nativescript-ui-sidedrawer/angular";
//import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import { RouterExtensions } from "nativescript-angular/router";
import { registerElement } from "nativescript-angular/element-registry";
import { CardView } from "nativescript-cardview";
import { DrawerTransitionBase, RadSideDrawer, SlideInOnTopTransition } from "nativescript-ui-sidedrawer";
import { filter } from "rxjs/operators";
import * as app from "tns-core-modules/application";
import { Booking } from "../shared/booking/booking.model";
import { BookingService } from "../shared/booking/booking.service";
import  {UserService} from "../shared/user.service";
import { Page } from "tns-core-modules/ui/page";


registerElement("CardView", () => CardView);




@Component({
    selector: "Search",
    templateUrl: "./search.component.html",
    styleUrls: ['./search.component.css']

})
export class SearchComponent implements OnInit {
    @ViewChild('rsd',{static: false}) rSideDrawer: ElementRef;

   // @ViewChild(RadSideDrawerComponent) drawerComponent: RadSideDrawerComponent;

   data = [];


   tasks = []; 
   private _activatedUrl: string;
   private _sideDrawerTransition: DrawerTransitionBase;

    //data = [];
    //private bookings:Booking;

    constructor(private page:Page,private userService: UserService, private bookingService: BookingService, private routerExtensions: RouterExtensions,private router:Router) {
        // Use the component constructor to inject providers.
    }

    ngOnInit(): void {
       // this.data.push({ heading: "Bulbasaur", content: "Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun’s rays, the seed grows progressively larger." });


        // Init your component properties here.
    
        this.bookingService.get().subscribe((data) => {
            this.tasks = data;
        }, () => {
        });

        this.page.actionBarHidden = false;

    }
    drawerLoaded(args) {
        let drawer = <RadSideDrawer>args.object;
    }

    onOpenDrawerTap(): void {
        this.rSideDrawer.nativeElement.toggleDrawerState();
    }

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.showDrawer();
    }

   // get booking():Booking{
       // return this.bookings;
   // }

    get sideDrawerTransition():DrawerTransitionBase{
        return this._sideDrawerTransition;
    }

    isComponentSelected(url: string): boolean {
        return this._activatedUrl === url;
    }

    onNavItemTap(navItemRoute: string): void {
        this.routerExtensions.navigate([navItemRoute], {
            transition: {
                name: "fade"
            }
        });

        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.closeDrawer();
    }

    redirectBook(){
        this.routerExtensions.navigate(["/home"], { clearHistory: true });
    }
    redirectNav(){
        this.routerExtensions.navigate(["/nav"], { clearHistory: false });
    }
    activeUser(){
        return this.userService.activeUserId;
     }
     get(){
        this.bookingService.get();
    };
    logout() {
        this.userService.logout();
        this.routerExtensions.navigate(["/login"], { clearHistory: true });
    };
    newUser(){
        return this.userService.verify();
    }
    registerLive(){

    }
}
