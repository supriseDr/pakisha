// The following is a sample implementation of a backend service using Progress Kinvey (https://www.progress.com/kinvey).
// Feel free to swap in your own service / APIs / etc here for your own apps.

import { Injectable } from "@angular/core";
import * as Kinvey from "kinvey-nativescript-sdk";
// TODO: should be imported from kinvey-nativescript-sdk/angular but declaration file is currently missing
import { UserService as KinveyUserService } from "kinvey-nativescript-sdk/lib/angular";
import { User } from "./user.model";

@Injectable()
export class UserService {

    public _error = [];
    constructor(private kinveyUserService: KinveyUserService) { }

    register(user: User) {
        return this.kinveyUserService.signup({ username: user.email, password: user.password })
            .catch(this.handleErrors);
    }

    login(user: User) {
        return this.kinveyUserService.login(user.email, user.password)
            .catch(this.handleErrors);
    }

    logout() {
        return this.kinveyUserService.logout()
            .catch(this.handleErrors);
    }

    activeUserId(){
        return this.kinveyUserService.getActiveUser()._id;
        
    }

    activeUser(){
      //return this.kinveyUserService.getActiveUser().isActive;
      return this.kinveyUserService.getActiveUser().isActive;
    }

    resetPassword(email:string) {
      return this.kinveyUserService.resetPassword(email)
      .then((data) => {
        //console.debug('Data', data)
       }).catch(this.handleErrors);
  }
  /*
   public forgetPassword(email: string) {
        return this._userService.resetPassword(email)
            .then((data) => {
                console.debug('Data', data)
            })
            .catch((error: Kinvey.Errors.BaseError) => {
                console.debug('Error', error)
            });
    }
  */

  registerLservice(){
    var activeUser = this.kinveyUserService.getActiveUser();
    return activeUser.registerForLiveService()
    .catch(this.handleErrors);
  }
  verify(){
    const userData = this.kinveyUserService.getActiveUser().username;
    //onst user = new Kinvey.User(userData);
    
    //console.log(user);
   // const user = new Kinvey.User(userData);
   // const promise = user.verifyEmail()
   //   .then((response: any) => {
        // ...
   //   })
    //  .catch((error: Kinvey.BaseError) => {
        // ...
   //   });
  }
    /*
    async resetPassword(email: string) {
        try {
          const response = await this.kinveyUserService.resetPassword(email);
          //KinveyUserService.resetPassword(email);
          console.log(response);
        } catch (error) {
          console.log(error);
        }
      }
      */

    handleErrors(error: Kinvey.Errors.BaseError) {
        alert(error.message);
        return Promise.reject(error.message);
    }
}
