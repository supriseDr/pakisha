import { Injectable } from "@angular/core";
import * as Kinvey from "kinvey-nativescript-sdk";


@Injectable()
export class TasksService {
    private dataStore;

    constructor() {
        this.dataStore = Kinvey.DataStore.collection("Tasks",Kinvey.DataStoreType.Network);
        this.dataStore.subscribe({
            onMessage: (m) => {
              // handle incoming updates of entities in this collection
            },
            onStatus: (s) => {
              // handle status events, which pertain to this collection
            },
            onError: (e) => {
              // handle error events, which pertain to this collection
            }
          })
           
    }

    get() {
        const query = new Kinvey.Query();
        // Sort by descending “entity created time” to put new items on top.
        query.descending("_kmd.ect");
        return this.dataStore.find(query);
    }

    save(task) {
        return this.dataStore.save(task);
    }

    handleErrors(error: Kinvey.Errors.BaseError) {
        console.error(error.message);
        return Promise.reject(error.message);
    }
}