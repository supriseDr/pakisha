
export class Booking {

    pickup:String;
    destination:String;
    date:Date; 
    time:Date; 
    seats:number;
    age:number;
    luggage:number;
    cellno:Number;
    confirm:boolean

}