import { Injectable } from "@angular/core";
import { DataStoreService, FilesService, UserService, Query} from "kinvey-nativescript-sdk/lib/angular";
import * as Kinvey from "kinvey-nativescript-sdk";
import {UserService as kinveyUserService} from "kinvey-nativescript-sdk/lib/angular";

//import { Config } from "../../shared/config";
import { Booking } from "../../browse/browse.component";

@Injectable({
    providedIn: "root"
})

export class BookingService{
    
    private dataStore;

    constructor(private kinveyUserService:kinveyUserService) {
        this.dataStore = Kinvey.DataStore.collection("bookings");
    }

    get() {
        const query = new Kinvey.Query();
        query.equalTo('userId',this.kinveyUserService.getActiveUser()._id);
        query.descending('_kmd.ect');
        return this.dataStore.find(query)
    };

    //save(task) {
        //return this.dataStore.save(task);
    //}
     //Access the models
     save(booking:Booking){
        return this.dataStore.save({
            location:booking.pickup,
            destination:booking.destination,
            date:booking.date, 
            departure:booking.time,
            seats:booking.seats,
            age:booking.age,
            laggage:booking.luggage,
            cellno:booking.cellno,
            confirmed:booking.confirm,
            username:this.kinveyUserService.getActiveUser().username,
            userId:this.kinveyUserService.getActiveUser()._id

        })
        .then(function(entity:{}){
        })
        .catch(this.handleErrors)
    };

    handleErrors(error: Kinvey.Errors.BaseError) {
        console.error(error.message);
        return Promise.reject(error.message);
    }
}