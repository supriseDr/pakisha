import { Component, OnInit } from "@angular/core";
import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import * as app from "tns-core-modules/application";
//import * as appSettings from "tns-core-modules/application-settings";
import {
    getBoolean,
    setBoolean,
    getNumber,
    setNumber,
    getString,
    setString,
    hasKey,
    remove,
    clear
} from "tns-core-modules/application-settings";

@Component({
    selector: "Settings",
    templateUrl: "./settings.component.html",
    styleUrls:['./settings.component.css']
})
export class SettingsComponent implements OnInit {

    credit:string=getString("cardNumber");
    name:string=getString("name");
    surname:string=getString("surname");
    gender:string=getString("gender");
    location:string=getString("location");
    birthDate:string=getString("birthDate");
    phone:string=getString("phone");
    constructor() {
        // Use the component constructor to inject providers.
    }

    ngOnInit(): void {
        // Init your component properties here. 
        
    }
    saveString(){
        setString("cardNumber",this.credit);
        setString("name",this.name);
        setString("surname",this.surname);
        setString("phone",this.phone);
        setString("location",this.location);
        setString("gender",this.gender);
        setString("birthDate",this.birthDate);
    }

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.showDrawer();
    }
}
